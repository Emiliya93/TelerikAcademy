﻿namespace DefineClass
{
    public enum BatteryType
    {
        LiIon, NiMH, NiCd
    }
}
