﻿namespace RefactorTheIfStatements
{
    public class Potato
    {
        public Potato()
        {
        }

        public bool HasNotBeenPeeled { get; set; }

        public bool IsRotten { get; set; }
    }
}
