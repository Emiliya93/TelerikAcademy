﻿namespace Chef
{
    public class Vegetable
    {
        public Vegetable()
        {
        }
    }
}
