﻿namespace Chef
{
    public class Carrot : Vegetable
    {
        public Carrot()
        {
        }
    }
}
