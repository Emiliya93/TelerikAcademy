﻿namespace Chef
{
    public class Potato : Vegetable
    {
        public Potato()
        {
        }
    }
}
