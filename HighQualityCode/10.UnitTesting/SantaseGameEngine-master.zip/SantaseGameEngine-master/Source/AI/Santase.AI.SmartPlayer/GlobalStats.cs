﻿namespace Santase.AI.SmartPlayer
{
    public static class GlobalStats
    {
        public static int GamesClosedByPlayer { get; set; }
    }
}
